# 🚀 DATABROKERS - Sistema de Gestión de Modelos de Negocio

![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)
![Node](https://img.shields.io/badge/node-18.x-brightgreen.svg)
![PostgreSQL](https://img.shields.io/badge/postgresql-15+-blue.svg)

Sistema integral de gestión para administrar múltiples modelos de negocio inmobiliario, optimizando la gestión de stock, el seguimiento de operaciones y la medición del desempeño.

---

## 📋 Tabla de Contenidos

- [Características Principales](#-características-principales)
- [Stack Tecnológico](#-stack-tecnológico)
- [Requisitos Previos](#-requisitos-previos)
- [Instalación](#-instalación)
- [Configuración](#-configuración)
- [Uso](#-uso)
- [Estructura del Proyecto](#-estructura-del-proyecto)
- [API Endpoints](#-api-endpoints)
- [Testing](#-testing)
- [Despliegue](#-despliegue)
- [Contribución](#-contribución)
- [Licencia](#-licencia)

---

## ✨ Características Principales

### 🏢 Gestión de Propiedades
- Control de stock en tiempo real
- Jerarquía: Proyecto → Tipo de unidad → Unidad individual
- Fichas técnicas con imágenes y documentación
- Carga masiva mediante CSV
- Compartir fichas mediante URL o PDF

### 💼 CRM y Pipeline
- Gestión completa de clientes
- Pipeline visual con drag & drop
- Seguimiento de oportunidades
- Registro de interacciones
- Análisis de motivos de pérdida

### 📄 Cotizaciones
- Cálculo automático de precios
- Versionado de cotizaciones
- Exportación a PDF con branding
- Seguimiento de estado

### 🔔 Sistema de Alertas
- Alertas de nuevos negocios
- Notificaciones de cambios de estado
- Alertas de cancelación con motivo
- Configuración por rol

### 📊 KPIs y Reportería
- Desempeño por modelo de negocio
- Performance individual de gestores
- Reportes consolidados
- Dashboard ejecutivo interactivo
- Exportación a PDF, Excel, MS Access

---

## 🛠️ Stack Tecnológico

### Frontend
- **React 18** + TypeScript
- **Material-UI (MUI)** v5
- React Router v6
- Axios + React Query
- Chart.js / Recharts
- Formik + Yup

### Backend
- **Node.js 18 LTS**
- **Express 4.x**
- **Sequelize ORM**
- JWT + bcrypt
- Winston (logging)
- Jest (testing)

### Base de Datos
- **PostgreSQL 15+**
- PostGIS (extensión)
- Redis (caché)

### DevOps
- Docker + Docker Compose
- Nginx
- PM2

---

## 📦 Requisitos Previos

- Node.js >= 18.x
- PostgreSQL >= 15.x
- Redis >= 7.x (opcional)
- npm o yarn
- Git

---

## 🚀 Instalación

### 1. Clonar el repositorio

```bash
git clone https://github.com/tu-empresa/databrokers.git
cd databrokers
```

### 2. Backend

```bash
cd backend
npm install
cp .env.example .env
# Editar .env con tus configuraciones
npm run migrate
npm run seed
npm run dev
```

### 3. Frontend

```bash
cd frontend
npm install
cp .env.example .env
# Editar .env con la URL de tu API
npm start
```

### 4. Base de Datos

```bash
# Crear base de datos
createdb databrokers

# Ejecutar schema
psql databrokers < database/schema.sql
```

---

## ⚙️ Configuración

### Variables de Entorno - Backend

```env
# Server
NODE_ENV=development
PORT=5000

# Database
DB_HOST=localhost
DB_PORT=5432
DB_NAME=databrokers
DB_USER=postgres
DB_PASSWORD=tu_password

# JWT
JWT_SECRET=tu_secreto_muy_seguro_aqui
JWT_EXPIRES_IN=24h
REFRESH_TOKEN_SECRET=otro_secreto_muy_seguro
REFRESH_TOKEN_EXPIRES_IN=7d

# Redis (opcional)
REDIS_HOST=localhost
REDIS_PORT=6379

# Email (opcional)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=tu_email@gmail.com
SMTP_PASSWORD=tu_password

# Storage (S3/MinIO)
AWS_REGION=us-east-1
AWS_BUCKET=databrokers
AWS_ACCESS_KEY_ID=tu_access_key
AWS_SECRET_ACCESS_KEY=tu_secret_key
```

### Variables de Entorno - Frontend

```env
REACT_APP_API_URL=http://localhost:5000/api
REACT_APP_ENV=development
```

---

## 🎯 Uso

### Usuario por defecto

```
Email: admin@databrokers.cl
Contraseña: Admin123!
```

**⚠️ IMPORTANTE: Cambiar esta contraseña en producción**

### Carga masiva de datos

```bash
# Importar propiedades desde CSV
curl -X POST http://localhost:5000/api/properties/import \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -F "file=@propiedades.csv"
```

Formato CSV:
```csv
project_id,unit_type_id,unit_number,floor,status,price
1,1,"101",1,"available",85000000
```

---

## 📁 Estructura del Proyecto

```
databrokers/
├── backend/
│   ├── src/
│   │   ├── config/          # Configuraciones
│   │   ├── controllers/     # Lógica de endpoints
│   │   ├── models/          # Modelos Sequelize
│   │   ├── routes/          # Definición de rutas
│   │   ├── middlewares/     # Auth, validación, etc.
│   │   ├── services/        # Lógica de negocio
│   │   ├── utils/           # Helpers
│   │   └── app.js
│   ├── migrations/
│   ├── seeders/
│   ├── tests/
│   └── server.js
│
├── frontend/
│   ├── public/
│   ├── src/
│   │   ├── api/             # API calls
│   │   ├── components/      # Componentes
│   │   ├── pages/           # Vistas
│   │   ├── hooks/           # Custom hooks
│   │   ├── context/         # Context API
│   │   ├── utils/           # Helpers
│   │   └── App.tsx
│   └── package.json
│
├── database/
│   ├── schema.sql           # Schema PostgreSQL
│   └── seeds/               # Datos iniciales
│
├── docs/
│   └── *.docx               # Documentación
│
└── docker-compose.yml
```

---

## 🔗 API Endpoints

### Autenticación
```
POST   /api/auth/login
POST   /api/auth/register
POST   /api/auth/refresh-token
POST   /api/auth/logout
```

### Usuarios
```
GET    /api/users
GET    /api/users/:id
POST   /api/users
PUT    /api/users/:id
DELETE /api/users/:id
```

### Propiedades
```
GET    /api/properties
GET    /api/properties/:id
POST   /api/properties
PUT    /api/properties/:id
DELETE /api/properties/:id
POST   /api/properties/import     # CSV upload
GET    /api/properties/export     # CSV download
```

### Proyectos
```
GET    /api/projects
GET    /api/projects/:id
POST   /api/projects
PUT    /api/projects/:id
DELETE /api/projects/:id
```

### Clientes
```
GET    /api/clients
GET    /api/clients/:id
POST   /api/clients
PUT    /api/clients/:id
DELETE /api/clients/:id
```

### Oportunidades
```
GET    /api/opportunities
GET    /api/opportunities/:id
POST   /api/opportunities
PUT    /api/opportunities/:id
DELETE /api/opportunities/:id
PATCH  /api/opportunities/:id/stage
```

### Cotizaciones
```
GET    /api/quotations
GET    /api/quotations/:id
POST   /api/quotations
PUT    /api/quotations/:id
GET    /api/quotations/:id/pdf
```

### Reportes
```
GET    /api/reports
POST   /api/reports/generate
GET    /api/reports/:id/download
```

### Dashboard
```
GET    /api/dashboard/kpis
GET    /api/dashboard/charts
```

---

## 🧪 Testing

### Backend

```bash
# Unit tests
npm test

# Coverage
npm run test:coverage

# Watch mode
npm run test:watch
```

### Frontend

```bash
# Unit tests
npm test

# E2E tests
npm run test:e2e
```

---

## 🚢 Despliegue

### Con Docker

```bash
# Build
docker-compose build

# Run
docker-compose up -d

# Ver logs
docker-compose logs -f
```

### Sin Docker

```bash
# Backend
cd backend
npm run build
NODE_ENV=production pm2 start dist/server.js --name databrokers-api

# Frontend
cd frontend
npm run build
# Servir carpeta build con Nginx
```

---

## 🤝 Contribución

1. Fork el proyecto
2. Crea una rama (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add: amazing feature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

### Convenciones de Commits

- `Add:` Nueva funcionalidad
- `Fix:` Corrección de bugs
- `Update:` Actualización de funcionalidad existente
- `Remove:` Eliminación de código
- `Refactor:` Refactorización
- `Docs:` Documentación

---

## 📄 Licencia

Este proyecto está bajo la Licencia MIT. Ver archivo `LICENSE` para más detalles.

---

## 👥 Equipo

- **Desarrollador Principal**: Tu Nombre
- **Email**: contacto@databrokers.cl
- **Website**: https://databrokers.cl

---

## 📞 Soporte

¿Necesitas ayuda? 

- 📧 Email: soporte@databrokers.cl
- 💬 Slack: [databrokers.slack.com](https://databrokers.slack.com)
- 📖 Docs: [docs.databrokers.cl](https://docs.databrokers.cl)

---

## 🗺️ Roadmap

### Versión 1.1 (Q1 2026)
- [ ] Integración con WhatsApp Business
- [ ] App móvil (React Native)
- [ ] API pública para integraciones
- [ ] Módulo de contratos digitales

### Versión 1.2 (Q2 2026)
- [ ] Machine Learning para predicción de ventas
- [ ] Chatbot con IA
- [ ] Integración con sistemas contables
- [ ] Multi-idioma

---

**¡Construido con ❤️ por el equipo de DataBrokers!**
