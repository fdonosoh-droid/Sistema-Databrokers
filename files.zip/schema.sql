-- ==============================================
-- DATABROKERS - SCHEMA POSTGRESQL
-- Sistema de Gestión de Modelos de Negocio
-- Versión: 1.0
-- Encoding: UTF-8 sin BOM
-- ==============================================

-- Extensiones necesarias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "postgis";

-- ==============================================
-- 1. TABLA: users
-- Usuarios del sistema
-- ==============================================
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  role VARCHAR(50) NOT NULL CHECK (role IN ('admin', 'analyst', 'executive', 'viewer')),
  phone VARCHAR(50),
  avatar_url VARCHAR(500),
  is_active BOOLEAN DEFAULT true,
  last_login TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  created_by INTEGER REFERENCES users(id)
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_active ON users(is_active);

-- ==============================================
-- 2. TABLA: business_models
-- Modelos de negocio
-- ==============================================
CREATE TABLE business_models (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  description TEXT,
  type VARCHAR(50) NOT NULL CHECK (type IN ('sale', 'rent', 'project', 'management', 'custom')),
  config JSONB DEFAULT '{}',
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_business_models_type ON business_models(type);
CREATE INDEX idx_business_models_active ON business_models(is_active);

-- ==============================================
-- 3. TABLA: projects
-- Proyectos inmobiliarios
-- ==============================================
CREATE TABLE projects (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  business_model_id INTEGER REFERENCES business_models(id),
  developer VARCHAR(255),
  address VARCHAR(500),
  city VARCHAR(100),
  region VARCHAR(100),
  country VARCHAR(100) DEFAULT 'Chile',
  location GEOGRAPHY(POINT),
  total_units INTEGER,
  available_units INTEGER,
  description TEXT,
  amenities JSONB DEFAULT '[]',
  images JSONB DEFAULT '[]',
  status VARCHAR(50) DEFAULT 'planning' CHECK (status IN ('planning', 'construction', 'sales', 'completed')),
  start_date DATE,
  expected_completion DATE,
  metadata JSONB DEFAULT '{}',
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  created_by INTEGER REFERENCES users(id)
);

CREATE INDEX idx_projects_status ON projects(status);
CREATE INDEX idx_projects_business_model ON projects(business_model_id);
CREATE INDEX idx_projects_location ON projects USING GIST(location);
CREATE INDEX idx_projects_city ON projects(city);
CREATE INDEX idx_projects_active ON projects(is_active);

-- ==============================================
-- 4. TABLA: unit_types
-- Tipos de unidades/tipologías
-- ==============================================
CREATE TABLE unit_types (
  id SERIAL PRIMARY KEY,
  project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
  name VARCHAR(100) NOT NULL,
  bedrooms INTEGER,
  bathrooms DECIMAL(3,1),
  surface_total DECIMAL(10,2),
  surface_useful DECIMAL(10,2),
  surface_terrace DECIMAL(10,2),
  base_price DECIMAL(15,2),
  floor_plans JSONB DEFAULT '[]',
  features JSONB DEFAULT '{}',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_unit_types_project ON unit_types(project_id);
CREATE INDEX idx_unit_types_bedrooms ON unit_types(bedrooms);

-- ==============================================
-- 5. TABLA: properties
-- Unidades individuales
-- ==============================================
CREATE TABLE properties (
  id SERIAL PRIMARY KEY,
  project_id INTEGER REFERENCES projects(id),
  unit_type_id INTEGER REFERENCES unit_types(id),
  unit_number VARCHAR(50) NOT NULL,
  floor INTEGER,
  orientation VARCHAR(50),
  view_type VARCHAR(100),
  status VARCHAR(50) DEFAULT 'available' 
    CHECK (status IN ('available', 'reserved', 'sold', 'rented', 'maintenance', 'unavailable')),
  price DECIMAL(15,2),
  discount_percentage DECIMAL(5,2) DEFAULT 0,
  final_price DECIMAL(15,2),
  images JSONB DEFAULT '[]',
  documents JSONB DEFAULT '[]',
  virtual_tour_url VARCHAR(500),
  metadata JSONB DEFAULT '{}',
  reserved_until TIMESTAMP,
  sold_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  created_by INTEGER REFERENCES users(id)
);

CREATE INDEX idx_properties_status ON properties(status);
CREATE INDEX idx_properties_project ON properties(project_id);
CREATE INDEX idx_properties_unit_type ON properties(unit_type_id);
CREATE INDEX idx_properties_price ON properties(price);
CREATE UNIQUE INDEX idx_properties_unit_number ON properties(project_id, unit_number);

-- Trigger para calcular final_price automáticamente
CREATE OR REPLACE FUNCTION calculate_final_price()
RETURNS TRIGGER AS $$
BEGIN
  NEW.final_price := NEW.price * (1 - COALESCE(NEW.discount_percentage, 0) / 100);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_properties_final_price
BEFORE INSERT OR UPDATE ON properties
FOR EACH ROW
EXECUTE FUNCTION calculate_final_price();

-- ==============================================
-- 6. TABLA: clients
-- Clientes
-- ==============================================
CREATE TABLE clients (
  id SERIAL PRIMARY KEY,
  type VARCHAR(50) DEFAULT 'person' CHECK (type IN ('person', 'company')),
  first_name VARCHAR(100),
  last_name VARCHAR(100),
  company_name VARCHAR(255),
  tax_id VARCHAR(50),
  email VARCHAR(255),
  phone VARCHAR(50),
  mobile VARCHAR(50),
  address VARCHAR(500),
  city VARCHAR(100),
  country VARCHAR(100),
  source VARCHAR(100),
  notes TEXT,
  tags JSONB DEFAULT '[]',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  created_by INTEGER REFERENCES users(id)
);

CREATE INDEX idx_clients_email ON clients(email);
CREATE INDEX idx_clients_tax_id ON clients(tax_id);
CREATE INDEX idx_clients_type ON clients(type);
CREATE INDEX idx_clients_source ON clients(source);

-- ==============================================
-- 7. TABLA: opportunities
-- Pipeline de ventas/arriendo
-- ==============================================
CREATE TABLE opportunities (
  id SERIAL PRIMARY KEY,
  business_model_id INTEGER REFERENCES business_models(id),
  client_id INTEGER REFERENCES clients(id),
  property_id INTEGER REFERENCES properties(id),
  assigned_to INTEGER REFERENCES users(id),
  name VARCHAR(255) NOT NULL,
  stage VARCHAR(100) NOT NULL,
  probability INTEGER CHECK (probability BETWEEN 0 AND 100),
  expected_value DECIMAL(15,2),
  expected_close_date DATE,
  actual_close_date DATE,
  lost_reason VARCHAR(255),
  notes TEXT,
  tags JSONB DEFAULT '[]',
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  created_by INTEGER REFERENCES users(id)
);

CREATE INDEX idx_opportunities_stage ON opportunities(stage);
CREATE INDEX idx_opportunities_assigned ON opportunities(assigned_to);
CREATE INDEX idx_opportunities_client ON opportunities(client_id);
CREATE INDEX idx_opportunities_property ON opportunities(property_id);
CREATE INDEX idx_opportunities_close_date ON opportunities(expected_close_date);
CREATE INDEX idx_opportunities_business_model ON opportunities(business_model_id);

-- ==============================================
-- 8. TABLA: quotations
-- Cotizaciones
-- ==============================================
CREATE TABLE quotations (
  id SERIAL PRIMARY KEY,
  opportunity_id INTEGER REFERENCES opportunities(id),
  property_id INTEGER REFERENCES properties(id),
  client_id INTEGER REFERENCES clients(id),
  version INTEGER DEFAULT 1,
  status VARCHAR(50) DEFAULT 'draft' CHECK (status IN ('draft', 'sent', 'accepted', 'rejected', 'expired')),
  base_price DECIMAL(15,2) NOT NULL,
  discount_amount DECIMAL(15,2) DEFAULT 0,
  discount_percentage DECIMAL(5,2) DEFAULT 0,
  subtotal DECIMAL(15,2),
  tax_amount DECIMAL(15,2),
  total DECIMAL(15,2),
  commission_percentage DECIMAL(5,2),
  commission_amount DECIMAL(15,2),
  payment_terms TEXT,
  valid_until DATE,
  notes TEXT,
  pdf_url VARCHAR(500),
  sent_at TIMESTAMP,
  accepted_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  created_by INTEGER REFERENCES users(id)
);

CREATE INDEX idx_quotations_status ON quotations(status);
CREATE INDEX idx_quotations_opportunity ON quotations(opportunity_id);
CREATE INDEX idx_quotations_client ON quotations(client_id);
CREATE INDEX idx_quotations_property ON quotations(property_id);

-- ==============================================
-- 9. TABLA: interactions
-- Interacciones con clientes
-- ==============================================
CREATE TABLE interactions (
  id SERIAL PRIMARY KEY,
  client_id INTEGER REFERENCES clients(id),
  opportunity_id INTEGER REFERENCES opportunities(id),
  user_id INTEGER REFERENCES users(id),
  type VARCHAR(50) NOT NULL CHECK (type IN ('call', 'email', 'meeting', 'visit', 'note')),
  subject VARCHAR(255),
  description TEXT,
  outcome VARCHAR(100),
  next_action VARCHAR(255),
  next_action_date DATE,
  duration_minutes INTEGER,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_interactions_client ON interactions(client_id);
CREATE INDEX idx_interactions_opportunity ON interactions(opportunity_id);
CREATE INDEX idx_interactions_user ON interactions(user_id);
CREATE INDEX idx_interactions_type ON interactions(type);
CREATE INDEX idx_interactions_date ON interactions(created_at);

-- ==============================================
-- 10. TABLA: alerts
-- Sistema de alertas
-- ==============================================
CREATE TABLE alerts (
  id SERIAL PRIMARY KEY,
  type VARCHAR(100) NOT NULL CHECK (type IN ('new_opportunity', 'stage_change', 'opportunity_won', 'opportunity_lost', 'property_status_change', 'low_stock')),
  severity VARCHAR(50) DEFAULT 'info' CHECK (severity IN ('info', 'warning', 'error', 'success')),
  title VARCHAR(255) NOT NULL,
  message TEXT,
  entity_type VARCHAR(100),
  entity_id INTEGER,
  user_id INTEGER REFERENCES users(id),
  is_read BOOLEAN DEFAULT false,
  read_at TIMESTAMP,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_alerts_user ON alerts(user_id);
CREATE INDEX idx_alerts_type ON alerts(type);
CREATE INDEX idx_alerts_is_read ON alerts(is_read);
CREATE INDEX idx_alerts_created ON alerts(created_at);

-- ==============================================
-- 11. TABLA: reports
-- Reportes generados
-- ==============================================
CREATE TABLE reports (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  type VARCHAR(100) NOT NULL CHECK (type IN ('business_model', 'consolidated', 'user_performance', 'custom')),
  business_model_id INTEGER REFERENCES business_models(id),
  parameters JSONB DEFAULT '{}',
  format VARCHAR(50) CHECK (format IN ('pdf', 'excel', 'json')),
  file_url VARCHAR(500),
  status VARCHAR(50) DEFAULT 'generating' CHECK (status IN ('generating', 'completed', 'failed')),
  error_message TEXT,
  generated_by INTEGER REFERENCES users(id),
  generated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_reports_type ON reports(type);
CREATE INDEX idx_reports_generated_by ON reports(generated_by);
CREATE INDEX idx_reports_business_model ON reports(business_model_id);
CREATE INDEX idx_reports_status ON reports(status);

-- ==============================================
-- 12. TABLA: audit_logs
-- Auditoría de acciones
-- ==============================================
CREATE TABLE audit_logs (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  action VARCHAR(100) NOT NULL,
  entity_type VARCHAR(100),
  entity_id INTEGER,
  old_values JSONB,
  new_values JSONB,
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_audit_user ON audit_logs(user_id);
CREATE INDEX idx_audit_entity ON audit_logs(entity_type, entity_id);
CREATE INDEX idx_audit_action ON audit_logs(action);
CREATE INDEX idx_audit_created ON audit_logs(created_at);

-- ==============================================
-- VISTAS PARA REPORTERÍA
-- ==============================================

-- Vista de performance por usuario
CREATE OR REPLACE VIEW vw_user_performance AS
SELECT 
  u.id,
  u.first_name,
  u.last_name,
  u.email,
  COUNT(DISTINCT o.id) AS total_opportunities,
  COUNT(DISTINCT CASE WHEN o.stage = 'closed-won' THEN o.id END) AS opportunities_won,
  COUNT(DISTINCT CASE WHEN o.stage = 'closed-lost' THEN o.id END) AS opportunities_lost,
  CASE 
    WHEN COUNT(DISTINCT o.id) > 0 
    THEN ROUND((COUNT(DISTINCT CASE WHEN o.stage = 'closed-won' THEN o.id END)::NUMERIC / COUNT(DISTINCT o.id)) * 100, 2)
    ELSE 0
  END AS conversion_rate,
  COALESCE(SUM(CASE WHEN o.stage = 'closed-won' THEN o.expected_value ELSE 0 END), 0) AS total_revenue,
  ROUND(AVG(CASE WHEN o.stage = 'closed-won' AND o.actual_close_date IS NOT NULL 
    THEN EXTRACT(EPOCH FROM (o.actual_close_date - o.created_at::date))/86400 
    ELSE NULL END), 2) AS avg_days_to_close
FROM users u
LEFT JOIN opportunities o ON u.id = o.assigned_to
WHERE u.role IN ('executive', 'admin')
GROUP BY u.id, u.first_name, u.last_name, u.email;

-- Vista de stock por proyecto
CREATE OR REPLACE VIEW vw_project_stock AS
SELECT 
  pr.id,
  pr.name,
  pr.city,
  pr.region,
  COUNT(p.id) AS total_units,
  COUNT(CASE WHEN p.status = 'available' THEN 1 END) AS available_units,
  COUNT(CASE WHEN p.status = 'reserved' THEN 1 END) AS reserved_units,
  COUNT(CASE WHEN p.status = 'sold' THEN 1 END) AS sold_units,
  COUNT(CASE WHEN p.status = 'rented' THEN 1 END) AS rented_units,
  ROUND(COUNT(CASE WHEN p.status IN ('sold', 'rented') THEN 1 END)::NUMERIC / 
        NULLIF(COUNT(p.id), 0) * 100, 2) AS occupancy_percentage
FROM projects pr
LEFT JOIN properties p ON pr.id = p.project_id
WHERE pr.is_active = true
GROUP BY pr.id, pr.name, pr.city, pr.region;

-- Vista de pipeline por modelo
CREATE OR REPLACE VIEW vw_pipeline_by_model AS
SELECT 
  bm.id,
  bm.name AS business_model,
  o.stage,
  COUNT(o.id) AS opportunity_count,
  COALESCE(SUM(o.expected_value), 0) AS pipeline_value,
  ROUND(AVG(o.probability), 2) AS avg_probability
FROM business_models bm
LEFT JOIN opportunities o ON bm.id = o.business_model_id
WHERE bm.is_active = true
GROUP BY bm.id, bm.name, o.stage;

-- ==============================================
-- DATOS INICIALES (SEEDS)
-- ==============================================

-- Usuario administrador por defecto
INSERT INTO users (email, password_hash, first_name, last_name, role, is_active)
VALUES ('admin@databrokers.cl', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5eko0ks8iXXBe', 'Admin', 'DataBrokers', 'admin', true);
-- Contraseña: Admin123! (debe cambiarse en producción)

-- Modelos de negocio por defecto
INSERT INTO business_models (name, description, type, is_active) VALUES
('Venta de Propiedades', 'Modelo de negocio para venta de propiedades inmobiliarias', 'sale', true),
('Arriendo de Propiedades', 'Modelo de negocio para arriendo de propiedades', 'rent', true),
('Proyectos Inmobiliarios', 'Gestión de proyectos inmobiliarios en desarrollo', 'project', true),
('Gestión de Propiedades', 'Administración de propiedades de terceros', 'management', true);

-- ==============================================
-- FUNCIONES Y TRIGGERS ADICIONALES
-- ==============================================

-- Función para actualizar updated_at automáticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Aplicar trigger a todas las tablas que tienen updated_at
CREATE TRIGGER trg_users_updated_at BEFORE UPDATE ON users
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_business_models_updated_at BEFORE UPDATE ON business_models
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_projects_updated_at BEFORE UPDATE ON projects
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_unit_types_updated_at BEFORE UPDATE ON unit_types
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_properties_updated_at BEFORE UPDATE ON properties
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_clients_updated_at BEFORE UPDATE ON clients
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_opportunities_updated_at BEFORE UPDATE ON opportunities
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_quotations_updated_at BEFORE UPDATE ON quotations
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Función para crear alertas automáticamente
CREATE OR REPLACE FUNCTION create_opportunity_alert()
RETURNS TRIGGER AS $$
DECLARE
  alert_type VARCHAR(100);
  alert_title VARCHAR(255);
  alert_message TEXT;
BEGIN
  -- Nueva oportunidad
  IF TG_OP = 'INSERT' THEN
    alert_type := 'new_opportunity';
    alert_title := 'Nueva oportunidad creada';
    alert_message := 'Se ha creado una nueva oportunidad: ' || NEW.name;
    
    -- Insertar alerta para admins y analistas
    INSERT INTO alerts (type, severity, title, message, entity_type, entity_id, user_id)
    SELECT alert_type, 'info', alert_title, alert_message, 'opportunity', NEW.id, id
    FROM users WHERE role IN ('admin', 'analyst');
    
  -- Cambio de stage
  ELSIF TG_OP = 'UPDATE' AND OLD.stage != NEW.stage THEN
    alert_type := 'stage_change';
    alert_title := 'Cambio de etapa en oportunidad';
    alert_message := 'La oportunidad "' || NEW.name || '" cambió de ' || OLD.stage || ' a ' || NEW.stage;
    
    -- Alerta al gestor asignado
    IF NEW.assigned_to IS NOT NULL THEN
      INSERT INTO alerts (type, severity, title, message, entity_type, entity_id, user_id)
      VALUES (alert_type, 'info', alert_title, alert_message, 'opportunity', NEW.id, NEW.assigned_to);
    END IF;
    
    -- Si se ganó
    IF NEW.stage = 'closed-won' THEN
      alert_type := 'opportunity_won';
      alert_title := '¡Oportunidad ganada!';
      alert_message := 'Se ha cerrado exitosamente: ' || NEW.name;
      
      INSERT INTO alerts (type, severity, title, message, entity_type, entity_id, user_id)
      SELECT alert_type, 'success', alert_title, alert_message, 'opportunity', NEW.id, id
      FROM users WHERE role IN ('admin', 'analyst');
    END IF;
    
    -- Si se perdió
    IF NEW.stage = 'closed-lost' THEN
      alert_type := 'opportunity_lost';
      alert_title := 'Oportunidad perdida';
      alert_message := 'Se ha perdido la oportunidad: ' || NEW.name || 
                       COALESCE(' - Motivo: ' || NEW.lost_reason, '');
      
      INSERT INTO alerts (type, severity, title, message, entity_type, entity_id, user_id)
      SELECT alert_type, 'warning', alert_title, alert_message, 'opportunity', NEW.id, id
      FROM users WHERE role IN ('admin', 'analyst');
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_opportunity_alerts
AFTER INSERT OR UPDATE ON opportunities
FOR EACH ROW
EXECUTE FUNCTION create_opportunity_alert();

-- ==============================================
-- FIN DEL SCRIPT
-- ==============================================

-- Verificar creación de tablas
SELECT 'Schema creado exitosamente. Total de tablas: ' || COUNT(*) 
FROM information_schema.tables 
WHERE table_schema = 'public' AND table_type = 'BASE TABLE';
